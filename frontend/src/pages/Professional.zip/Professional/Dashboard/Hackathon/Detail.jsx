import React from 'react';
import HackathonDetail from '@/components/Student/StudentDashboard/Hackathon/HackathonDetail';

const ProfessionalDetail = () => {
  return (
    <div className='bg-white'>
      <HackathonDetail />
    </div>
  );
};

export default ProfessionalDetail;