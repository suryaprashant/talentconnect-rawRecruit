import React from 'react';
import HackathonList from '@/components/Student/StudentDashboard/Hackathon/HackthonList';

const ProfessionalHackathon = () => {
  return (
    <div className='bg-white'>
      <HackathonList />
    </div>
  );
};

export default ProfessionalHackathon;
